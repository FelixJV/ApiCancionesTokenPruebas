package org.example.crudspringfjv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringFjvApplicationTests {

    @Test
    void contextLoads() {
    }

}
