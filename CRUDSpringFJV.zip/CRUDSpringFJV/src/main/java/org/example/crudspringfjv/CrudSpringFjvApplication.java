package org.example.crudspringfjv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudSpringFjvApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrudSpringFjvApplication.class, args);
    }

}
